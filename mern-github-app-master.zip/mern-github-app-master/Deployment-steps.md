# SETUP server.js (express.static and res.sendFile for react app)

# SETUP "build" and "start" scripts in package.json

# Deploy on render.com with env variables

# Update Github OAuth App (homepage url and callback url)

# Add CLIENT_BASE_URL as env variable on render

# Update the callback url on github.auth.js to full url (deployed url)

# Lastly, subscribe to make it work ;)
